#' @export

matrix.add.by.name<-function(M1,M2,...){
  add.by.name<-function(M1,M2){
    the.colnames<-colnames(M2)
    the.rownames<-rownames(M2)

    if (is.null(colnames(M1))||is.null(rownames(M1))||
        is.null(colnames(M2))||is.null(rownames(M2))) stop("Li, matrix.add.by.name: null name")

    if (any(!(the.colnames %in% colnames(M1)))) {
      print(paste(the.colnames[!(the.colnames %in% colnames(M1))]))
      stop("Li: wrong colnames")
    }

    if (any(!(the.rownames %in% rownames(M1)))) {
      print(paste(the.rownames[!(the.rownames %in% rownames(M1))]))
      stop("Li: wrong rownames")
    }

    M1[the.rownames, the.colnames]<-M1[the.rownames, the.colnames]+M2

    return(M1)
  }

  result<-add.by.name(as.matrix(M1),as.matrix(M2))

  M.list<-list(...)

  if (length(M.list)==0) return(result)
  else {
    for (k in 1:length(M.list)) result<-add.by.name(result, as.matrix(M.list[[k]]))

    return(result)
  }
}



