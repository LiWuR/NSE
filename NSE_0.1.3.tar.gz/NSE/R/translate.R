#A dictionary may contain more than 2 columns. So we do not use dict as a param.
#' @export
translate<-function(x, from=NSE::dictionary[,1], to=NSE::dictionary[,2], strict=FALSE){
  #If strict==FALSE, the original string may be returned. Otherwise NA may be returned.
  if (is.character(x)&&strict)  return(to[match(x,from)])
  if (is.character(x)&&!strict)  {
    tmp<-to[match(x,from)]
    return(ifelse(is.na(tmp), x, tmp))
  }

  if (is.vector(x))  {
      names(x)<-translate(names(x), from, to, strict)
      return(x)
  }

  if (is.matrix(x)||is.data.frame(x))  {
    rownames(x)<-translate(rownames(x), from, to, strict)
    colnames(x)<-translate(colnames(x), from, to, strict)
    return(x)
  }


}

# db <- dbConnect(RSQLite::SQLite(), "E:\\database\\SHUNSE.db")
# d<-dbReadTable(db, "dictionary")
# dbDisconnect(db)
# translate(c("VA002","EX"),d[,1],d[,2])
