#' @export

structure.adjust <- function(x, index, prop){
  stopifnot(is.numeric(x), x>=0, sum(x)>0,
            is.numeric(index), index %in% seq_along(x),
            length(prop)>=1, prop>=0, prop<=1)

  the.sum <- sum(x)

  x <- prop.table(x)

  if (length(prop)==1) {
    x[index] <- prop.table(x[index]) * prop

    x[-index] <- prop.table(x[-index]) * (1-prop)
  }
  else {
    stopifnot(length(index)==length(prop))

    x[index] <- prop

    x[-index] <- prop.table(x[-index]) * (1-sum(prop))
  }

  return(the.sum * prop.table(x))
}

