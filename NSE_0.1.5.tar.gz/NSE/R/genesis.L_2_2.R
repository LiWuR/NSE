#' @export

genesis.L_2_2<-function(){

  sdm(
    A=matrix(c(0, 1,
               1, 0),2,2,TRUE),
    B=matrix(c(1, 1,
               0, 1),2,2,TRUE),
    S0Exg=matrix(c(NA, NA,
                   NA, 1),2,2,TRUE),
    GRExg=0,
    z0=c(1,1),
    maxIteration=1,
    numberOfPeriods=20,
    ts=TRUE
  )
}

