#' @export

#two-sector corn economy with non-homothetic utility function
Example3.1.L_NH_2_2<-function(GRExg=0){
    rho<-1/(1+GRExg)

    sdm(
    GRExg=GRExg,
    A=function(state){
      with(state,{
        matrix(c(0.5, z[2]/(100*(1+GRExg)^t),
                 1,  1),2,2,T)
      })
    },
    B=diag(2),
    S0Exg=matrix(c(NA, NA,
                    NA, 100),2,2,TRUE),
    priceAdjustmentVelocity = 0.02,
    maxIteration=1,
    numberOfPeriods = 1000
  )
}

