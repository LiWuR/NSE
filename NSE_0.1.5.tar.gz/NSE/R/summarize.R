summarize<-function(ge){

}
