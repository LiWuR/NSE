#' @export

exchange.L_3_3<-function(
  A=matrix(c(0.9, 0.5, 0,
             0,   0,   1,
             0.1, 0.5, 0),3,3,TRUE),
  p=c(1, 1, 1),
  S=diag(c(100,10,100)),
  compute.ge=FALSE){


  x<-F_Z(A=A, p=p, S=S)

  print('The exchange vector is')
  print(x$z)

  print('The sales rate vector is')
  print(x$q)

  print('The purchase matrix is  ')
  print(A %*% dg(x$z))

  print('The sales matrix is')
  print(dg(x$q)%*%A)

  if (compute.ge)
    return(sdm(A=A,
               B=matrix(0, nrow(A), ncol(A)),
               S0Exg = {S[S==0]<-NA; S},
               GRExg = 0,
               p0=p,
               maxIteration = 1,
               numberOfPeriods = 100,
               trace=FALSE,
               ts=TRUE))
  else return(x)
}
