#' @import stringr
detectChineseCharacter<-function(string){
  return(str_detect(string, "[\\u4e00-\\u9fa5]"))
}

