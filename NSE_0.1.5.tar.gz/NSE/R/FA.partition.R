FA.partition<-function(row.sum, col.sum, M){
  stopifnot(sum(row.sum)==sum(col.sum))

  n.positive<-apply(M,1,function(x) sum(x>0)) #number of positive elements in each row
  result<- M-M
  resid.col.sum<-col.sum
  for (k in seq_along(row.sum)){
    i<-order(n.positive)[k]
    if (row.sum[i]==0) next
    result[i,]<-row.sum[i]*prop.table(resid.col.sum*M[i,])
    resid.col.sum<-resid.col.sum-result[i,]
  }

  stopifnot(abs(rowSums(result)-row.sum)<sum(row.sum)*1e-10,
            abs(colSums(result)-col.sum)<sum(row.sum)*1e-10)

  return(result)
}
# M<-matrix(c(1,1,1,
#             1,1,1,
#             1,0,0),3,3,byrow = T)
# FA.partition(c(100,200,200),c(200,200,100),M)
