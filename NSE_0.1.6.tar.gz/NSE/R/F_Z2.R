
F_Z2<-function (A,p,S){
  s<-rowSums(S)
  m<-ncol(S)

  Z<-dg(1/(t(p)%*%A))%*%prop.table(t(S),2)%*%dg(p)%*%A

  PF.vec <- cbind(rep(1,m))

  for (. in 1:20){
    PF.vec.old<-PF.vec
    for (. in 1:5) PF.vec<- Z %*% PF.vec
    PF.vec<-prop.table(PF.vec)
    tmp<-PF.vec/PF.vec.old
    tmp<-max(tmp)/min(tmp)
    if (tmp < 1+1e-10) break
  }


  z_structure<-PF.vec

  zeta<-min(s/(A%*%z_structure))
  z=zeta*z_structure;
  q=A%*%z/s
  list(z=z,q=q)
}
