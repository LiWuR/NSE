make.code<-function(type="I",n=19){
  result<-character(n)
  if ((n>0)&&(n<10)) for (k in 1:n) result[k]<-paste(type,k,"_",n,sep="")

  if ((n>10)&&(n<100)) for (k in 1:n) result[k]<-paste(type,sprintf("%02d", k),"_",n,sep="")

  if ((n>100)&&(n<1000)) for (k in 1:n) result[k]<-paste(type,sprintf("%02d", k),"_",n,sep="")

  return(result)
}
