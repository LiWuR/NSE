accelerate.capital.accumulation.L_3_3<-function(
    policy=function(time, state, state.history){
      if (time>=1&&time<=50) state$p<-c(100, 100, 1)
      state
    },
    z0=c(0.1,0.1,1),
    p0=c(1,1,1))
  {
    library(CGE)

    sdm(
      A=matrix(c(0.9, 0.5, 0,
                 0,   0,   1,
                 0.1, 0.5, 0),3,3,TRUE),
      B=diag(3),
      S0Exg=matrix(c(NA, NA, NA,
                     NA, NA, NA,
                     NA, NA, 100),3,3,TRUE),
      GRExg=0,
      z0=z0,
      p0=p0,
      maxIteration=1,
      plotIteration=T,
      numberOfPeriods=500,
      ts=T,
      policy = policy
    )
  }





