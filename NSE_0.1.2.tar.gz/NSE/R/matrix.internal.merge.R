matrix.internal.merge<-function(M, index.list, MARGIN=c(1,2)){

  col.merge<-function(M, index){
    first.of.index <- min(index)
    other.index <- index[index!=first.of.index]

    M[, first.of.index] <- rowSums(M[,index, drop=F])

    M[, other.index] <- NA

    return(M)
  }

  delete.na.col<-function(M){
    n.col<- ncol(M)
    for (k in n.col:1){
      if (all(is.na(M[,k]))) M <- M[,-k,drop=FALSE]
    }
    return(M)
  }

  M<-as.matrix(M)

  if (!is.list(index.list)) index.list<-list(index.list)

  #column
  if (2 %in% MARGIN){
    for (k in 1:length(index.list)){
      M <- col.merge(M, index.list[[k]])
    }
  }

  #row
  if (1 %in% MARGIN){
    for (k in 1:length(index.list)){
      M <- t(col.merge(t(M), index.list[[k]]))
    }
  }

  M <- delete.na.col(M)
  M <- t(delete.na.col(t(M)))

  return(M)
}


