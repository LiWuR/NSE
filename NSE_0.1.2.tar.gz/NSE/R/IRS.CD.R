IRS.CD_2_2.policy<-function(time, state, state.history){
  if ((time>=100)&&(time<120)) state$p<-c(0.99,0.01)
  if (time==120) state$p<-c(0.1,0.9)
  state
}


IRS.CD_2_2<-function(policy=NULL, technology.control=FALSE, z0=c(1,1), p0=c(1,1)){
  library(CGE)

  sdm(
    A=function(state){
      alpha<-rbind(NA,1)
      alpha[1] <- 5+10/(1+exp(20-state$z[1]))

      Beta<-matrix(c(0.5, 1,
                     0.5, 0),2,2,TRUE)

      if ((technology.control)&&(state$t>=100)&&(state$t<120)) tmp.p<-c(1, state$z[1])
      else tmp.p<-state$p

      CD_A(alpha,Beta,tmp.p)},
    B=matrix(c(1, 0,
               0, 1),2,2,TRUE),
    S0Exg=matrix(c(NA, NA,
                   NA, 1),2,2,TRUE),
    GRExg=0,
    z0=z0,
    p0=p0,
    maxIteration=1,
    plotIteration=T,
    numberOfPeriods=200,
    ts=T,
    policy=policy
  )
}


IRS.CD_2_3<-function(z0=c(30,30,1), p0=c(1,1)){
  library(CGE)

  sdm(
    A=function(state){
      alpha<-rbind(NA,6,1)
      alpha[1] <- 5+10/(1+exp(20-state$z[1]))

      Beta<-matrix(c(0.5, 0.5, 1,
                     0.5, 0.5, 0),2,3,TRUE)

      CD_A(alpha,Beta,state$p)},
    B=matrix(c(1, 1, 0,
               0, 0, 1),2,3,TRUE),
    S0Exg=matrix(c(NA, NA, NA,
                   NA, NA, 1),2,3,TRUE),
    GRExg=0,
    z0=z0,
    p0=p0,
    maxIteration=1,
    plotIteration=T,
    numberOfPeriods=200,
    ts=T
  )
}


IRS.CD_3_3<-function(technology.control=FALSE,
                     z0=c(1,1,1), p0=c(1,1,1)){
  library(CGE)

  sdm(
    A=function(state){
      alpha<-rbind(NA,1,1)
      alpha[1] <- 5+10/(1+exp(20-state$z[1]))

      Beta<-matrix(c(0.5, 0.99, 0,
                     0,   0,    1,
                     0.5, 0.01, 0),3,3,TRUE)

      if (technology.control&&(state$t>=100)&&(state$t<200)) tmp.p<-c(1, state$z[1],state$z[1])
      else tmp.p<-state$p

      CD_A(alpha,Beta,tmp.p)},
    B=diag(3),
    S0Exg=matrix(c(NA, NA, NA,
                   NA, NA, NA,
                   NA, NA, 1),3,3,TRUE),
    GRExg=0,
    z0=z0,
    p0=p0,
    maxIteration=1,
    plotIteration=T,
    numberOfPeriods=500,
    ts=T
  )
}



