#' @export

matrix.na.omit <- function(M, all.na.row=TRUE, all.na.col=TRUE,
                           any.na.row=FALSE, any.na.col=FALSE){
  stopifnot(is.matrix(M))

  matrix.delete.na.row<-function(M){
    flag.to.delete <- apply(M,1,function(the.row) if (all(is.na(the.row))) return(TRUE) else return(FALSE))
    return(M[!flag.to.delete,])
  }

  if (all.na.row) M <- matrix.delete.na.row(M)

  if (all.na.col) M <- t(matrix.delete.na.row(t(M)))

  if (any.na.row) M <- na.omit(M)

  if (any.na.col) M <- t(na.omit(t(M)))

  return(M)
}



