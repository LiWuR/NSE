#' @importFrom stats na.omit
#' @importFrom utils write.table
#' @import CGE
#' @export

ccge<-function(which = "ge",
               GRExg = 0,
               labor.supply = 100,
               ratio.consumption.investment.to.income = NULL,
               demand.structure.of.consumer = NULL,
               foreign.exchange.rate.coefficient = 1,
               consumption.substitution.elasticity = 0,
               IOT = NSE::ChinaInputOutputTable2012) {

  rownames(IOT)[rownames(IOT)=="VA001"]<-"CE"
  rownames(IOT)[rownames(IOT)=="VA002"]<-"NTP"
  rownames(IOT)[rownames(IOT)=="VA003"]<-"DFA"
  rownames(IOT)[rownames(IOT)=="VA004"]<-"OS"

  ######
  n.industry<-sum(str_detect(colnames(IOT),"I\\d"))

  # basic variables ：IOT ... ---------------------------------------------------------

  IOT1<-IOT[seq_len(n.industry), seq_len(n.industry)]
  IOT2<-IOT[seq_len(n.industry), -seq_len(n.industry)]
  IOT3<-IOT[-seq_len(n.industry), seq_len(n.industry)]

  IOT19<-data.compress(NSE::ChinaInputOutputTable2012)
  rownames(IOT19)[rownames(IOT19)=="VA001"]<-"CE"
  rownames(IOT19)[rownames(IOT19)=="VA002"]<-"NTP"
  rownames(IOT19)[rownames(IOT19)=="VA003"]<-"DFA"
  rownames(IOT19)[rownames(IOT19)=="VA004"]<-"OS"
  IOT1_19<-IOT19[1:19, 1:19]
  IOT2_19<-IOT19[1:19, -(1:19)]
  IOT3_19<-IOT19[-(1:19), 1:19]
  index.zero.import19 <- which(IOT2_19[,"IM"]==0)
  ratio.commodity.import19 <- IOT2_19[,"IM"]/rowSums(IOT2_19[,c("TIU","TC","GCF")])

  # names -------------------------------------------------------------------
  names.industry <- rownames(IOT)[1:n.industry]

  names.foreign.trade<-rownames(IOT2)[IOT2[,"IM"]>0]
  names.foreign.trade<-str_replace_all(names.foreign.trade,"I","FT")

  names.sector_product<-c(names.industry, names.foreign.trade)

  n.foreign.trade<-length(names.foreign.trade)

  names.subject<-c(names.industry, names.foreign.trade, "CE", "NTP", "OS", "DB", "FB")

  names.sector<-c(names.industry, names.foreign.trade, "HG", "ROW") #"RH", "UH", "G"

  n.sector<-length(names.sector)
  n.subject<-length(names.subject)

  # basic variables : index, ratio, rate -------------------------------------------------------
  index.zero.import <- which(IOT2[,"IM"]==0)

  ratio.commodity.import <- IOT2[,"IM"]/
    rowSums(IOT2[,c("TIU","TC","GCF")])


  depreciation.rate.sector19<-c(0.1015, 0.0720, 0.0798, 0.1280, 0.1853, 0.0377, 0.1778, 0.0892, 0.1057, 0.3020, 0.0382, 0.2007, 0.2007, 0.0265, 0.0910, 0.0265, 0.0844, 0.0341, 0.0378) #田友春，2016；是各行业投入的固定资产的折旧率，而非各行业产出的固定资产的折旧率（即各类固定资产的折旧率）。
  names(depreciation.rate.sector19)<-make.code(type = "I", n=19)

  # basic variables : alpha and beta -------------------------------------------------------
  beta<-rbind(prop.table(IOT2[,"EX"]))

  alpha<-1/prod((beta)^beta)

  # basic variables : consumption and investment ---------------------------------------------------------

  consumption <- rowSums(IOT2[,c("FU101","FU102","FU103")])

  consumption.total<-sum(consumption)
  household.income.total <- sum(IOT[c("CE","NTP","OS"),"TIU"])  #劳动者报酬与生产税净额与营业盈余之和;其中一部分为用来购买外国债券的foreign.trade.surplus

  foreign.trade.surplus <- sum(IOT2[,"EX"])-sum(IOT2[,"IM"])

  investment.domestic<-household.income.total-consumption.total-foreign.trade.surplus
  ratio.consumption.to.income <- consumption.total/household.income.total
  ratio.investment.domestic.to.income <- investment.domestic/household.income.total
  ratio.investment.foreign.to.income <- foreign.trade.surplus/household.income.total
  ratio.investment.domestic.to.consumption <- investment.domestic/consumption.total
  ratio.investment.foreign.to.consumption <- foreign.trade.surplus/consumption.total
  ratio.investment.domestic.to.TO<-investment.domestic/sum(IOT2[,"TO"])

  if (!is.null(ratio.consumption.investment.to.income)){
    ratio.consumption.to.income <- ratio.consumption.investment.to.income[1]
    ratio.investment.domestic.to.income <- ratio.consumption.investment.to.income[2]
    ratio.investment.foreign.to.income <- 1-sum(ratio.consumption.investment.to.income[1:2])
  }


  # granularity 19 to 42or139-------------------------------------------------------------
  tmp.colname<-paste("code",n.industry,sep="")
  tmp.table.industry<-unique(NSE::industryNames[,c(tmp.colname,"code19")])
  tmp.table.FT<-unique(NSE::foreignTradeNames[,c(tmp.colname,"code19")][as.logical(NSE::foreignTradeNames$IM139_2012), ])
  tmp.table <- rbind(tmp.table.industry, tmp.table.FT)
  granularity.industry<-split(tmp.table.industry[,1],tmp.table.industry[,2])
  granularity.FT<-split(tmp.table.FT[,1],tmp.table.FT[,2])
  granularity.sector_product<-split(tmp.table[,1],tmp.table[,2])


  # compute consumption structure ------------------------------------------------

  compute.consumption.structure <- function(state){
    #given by argument
    if (!is.null(demand.structure.of.consumer)){
      stopifnot(is.numeric(demand.structure.of.consumer),
                length(demand.structure.of.consumer)==n.industry+n.foreign.trade,
                demand.structure.of.consumer>=0,
                sum(demand.structure.of.consumer)>0)

      consumption.structure <- prop.table(demand.structure.of.consumer)

      return(consumption.structure)
    }

    #not given by argument

    if (consumption.substitution.elasticity==0)
      ratio.consumption.commodity.import <- ratio.commodity.import
    else {
      p <- as.vector(state$p)
      names(p) <- names.subject

      p.domestic <- p[names.industry]

      p.import <- rep(1,n.industry)
      p.import[-index.zero.import] <- p[names.foreign.trade]

      tmp.ratio.import_domestic <- ratio.commodity.import/(1-ratio.commodity.import)*(p.domestic/p.import)^consumption.substitution.elasticity
      ratio.consumption.commodity.import <- tmp.ratio.import_domestic/(tmp.ratio.import_domestic+1)
    }

    consumption.domestic <- consumption * (1-ratio.consumption.commodity.import)
    consumption.foreign <- (consumption * ratio.consumption.commodity.import)[-index.zero.import]

    consumption.structure<-prop.table(c(consumption.domestic, consumption.foreign))

    return(consumption.structure)
  }


  #basic input (i.e. intermediate input) and basic output
  compute.A.industry_basic<-function(){
    A.intermediate<-sweep(IOT1, 2, IOT2[,"TO"], "/")

    A.basic.domestic <- sweep(A.intermediate, 1, 1-ratio.commodity.import, "*")

    A.basic.import <- sweep(A.intermediate, 1, ratio.commodity.import, "*")
    A.basic.import <- A.basic.import[-index.zero.import,]
    rownames(A.basic.import) <- names.foreign.trade

    # return ------------------------------------------------------------------

    A.basic<-rbind(A.basic.domestic, A.basic.import)

    return(A.basic)
  }

  compute.B.industry_basic <- function(){
    B.basic <- diag(n.industry)
    dimnames(B.basic) <- list(names.industry, names.industry)

    return(B.basic)
  }

  compute.A.industry_labor <- function(){
    A.labor <- rbind(IOT3["CE",]/IOT2[,"TO"])
    dimnames(A.labor) <- list("CE", names.industry)

    return(A.labor)
  }

  compute.A.industry_production.tax<-function(state){
    p <- as.vector(state$p)
    names(p) <- names.subject

    ratio.production.tax.to.wage <- rbind(IOT3["NTP",]/IOT3["CE",])
    ratio.production.tax.to.wage[ratio.production.tax.to.wage<0] <- 0

    colnames(ratio.production.tax.to.wage) <- names.industry

    wage_unit.output <- p["CE"] * compute.A.industry_labor()
    A.production.tax <- rbind(wage_unit.output * ratio.production.tax.to.wage / p["NTP"])
    colnames(A.production.tax) <- names.industry
    rownames(A.production.tax) <- "NTP"

    return(A.production.tax)
  }

  compute.B.industry_production.tax<-function(state){
    p <- as.vector(state$p)
    names(p) <- names.subject

    ratio.production.tax.to.output <- rbind(IOT3["NTP",]/IOT2[ ,"TO"])
    ratio.production.tax.to.output[ratio.production.tax.to.output>0] <- 0
    ratio.production.tax.to.output <- -ratio.production.tax.to.output

    colnames(ratio.production.tax.to.output) <- names.industry

    B.production.tax <- rbind(p[names.industry] * ratio.production.tax.to.output / p["NTP"])
    colnames(B.production.tax) <- names.industry
    rownames(B.production.tax) <- "NTP"

    return(B.production.tax)
  }


  compute.A.industry_operating.surplus<-function(state){
    p <- as.vector(state$p)
    names(p) <- names.subject

    ratio.operating.surplus.to.wage <- rbind(IOT3["OS",]/IOT3["CE",])
    colnames(ratio.operating.surplus.to.wage) <- names.industry

    wage_unit.output <- p["CE"] * compute.A.industry_labor()
    A.operating.surplus <-
      rbind(wage_unit.output * ratio.operating.surplus.to.wage / p["OS"])
    colnames(A.operating.surplus) <- names.industry
    rownames(A.operating.surplus) <- "OS"

    return(A.operating.surplus)
  }

  compute.B.industry_bond.domestic <- function(state){
    p <- as.vector(state$p)
    names(p) <- names.subject

    B.bond.domestic <- rbind(rep(ratio.investment.domestic.to.TO, n.industry))

    #converging slowly
    #B.bond.domestic <- rbind(p[names.industry]*ratio.investment.domestic.to.TO)

    colnames(B.bond.domestic) <- names.industry
    row.names(B.bond.domestic) <- "DB"

    return(B.bond.domestic)
  }


  compute.A.foreign.trade <- function(state){
    p <- as.vector(state$p)
    names(p) <- names.subject

    A.foreign.trade <- CGE::CD_A(rep(alpha * foreign.exchange.rate.coefficient,
                                     n.foreign.trade),
                                 matrix(beta, n.industry, n.foreign.trade),
                                 p[names.industry])
    colnames(A.foreign.trade) <- names.foreign.trade
    rownames(A.foreign.trade) <- names.industry

    return (A.foreign.trade)
  }

  compute.B.foreign.trade <- function(){
    B.foreign.trade <- diag(n.foreign.trade)
    colnames(B.foreign.trade) <- rownames(B.foreign.trade) <- names.foreign.trade
    return(B.foreign.trade)
  }

  compute.A.industry_fixed.assets <- function(matrix19col=FALSE){
   #!!!!! to be written
    # A.B<-ccge19(which = "A.B")
    # the.A<-(A.B$A.industry_fixed.assets)
    # the.A<-translate(the.A, from=c(NSE::foreignTradeNames$name19AbbrChn,NSE::industryNames$name19AbbrChn),
    #                  to=c(NSE::foreignTradeNames$code19,NSE::industryNames$code19), strict=FALSE)
    tmp<-c(0.1, 0.1, 0.1, 0.1, 0.05, 0.1, 0.1, 0.1, 0.1, 0.1, 0.05, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1)
    prop.fixed.assets.type <- prop.table(IOT2_19[,"FU201"]/tmp)

    fixed.assets.stock.sector <-as.numeric(IOT3_19["DFA",]/depreciation.rate.sector19) #单位为万元
    fixed.assets.stock.type <- sum(fixed.assets.stock.sector)*prop.fixed.assets.type

    fixed.assets.input<-FA.partition(row.sum=fixed.assets.stock.type,
                                     col.sum=fixed.assets.stock.sector,
                                     M=FA.partition.coefficient.matrix(which=19))

    A.fixed.assets.whole <- sweep(fixed.assets.input, 2, IOT2_19[, "TO"], "/")

    A.fixed.assets.domestic <- sweep(A.fixed.assets.whole, 1, 1-ratio.commodity.import19, "*")
    rownames(A.fixed.assets.domestic) <- make.code(type="I",n=19)

    A.fixed.assets.import <- sweep(A.fixed.assets.whole, 1, ratio.commodity.import19, "*")
    rownames(A.fixed.assets.import) <- make.code(type="FT",n=19)
    A.fixed.assets.import <- A.fixed.assets.import[-index.zero.import19, ]

    the.A <- rbind(A.fixed.assets.domestic, A.fixed.assets.import)
    colnames(the.A)<-make.code(type="I",n=19)

    if (matrix19col) return(the.A)

    the.A<-matrix.expand.by.name(the.A, row.name.list =  granularity.sector_product)
    the.A<-matrix.expand.by.name(the.A, col.name.list =  granularity.industry, replicate = TRUE)

    return(the.A)

    # rownames(IOT2)[IOT2[,"FU201"]>0]
    #
    # fixed.assets.input <- matrix(1000, n.industry, n.industry,
    #                              dimnames = list(names.industry, names.industry));
    #
    #
    # A.fixed.assets.whole <- sweep(fixed.assets.input, 2, IOT2[, "TO"], "/")
    #
    # A.fixed.assets.domestic <- sweep(A.fixed.assets.whole, 1, 1-ratio.commodity.import, "*")
    #
    # A.fixed.assets.import <- sweep(A.fixed.assets.whole, 1, ratio.commodity.import, "*")
    # A.fixed.assets.import <- A.fixed.assets.import[-index.zero.import, ]
    #
    # rownames(A.fixed.assets.import) <-  names.foreign.trade
    #
    # A.fixed.assets <- rbind(A.fixed.assets.domestic, A.fixed.assets.import)
    #
    # return(A.fixed.assets)
  }

  compute.B.industry_fixed.assets <- function(){
    #!!!!! to be written
    # A.B<-ccge19(which = "A.B")
    #
    # the.B<-(A.B$B.industry_fixed.assets)
    #
    #
    # the.B<-translate(the.B, from=c(NSE::foreignTradeNames$name19AbbrChn,NSE::industryNames$name19AbbrChn),
    #                  to=c(NSE::foreignTradeNames$code19,NSE::industryNames$code19), strict=FALSE)

    the.B <- sweep(compute.A.industry_fixed.assets(matrix19col = TRUE),
                   2,
                   1-depreciation.rate.sector19, "*")

    the.B<-matrix.expand.by.name(the.B, row.name.list =  granularity.sector_product)
    the.B<-matrix.expand.by.name(the.B, col.name.list =  granularity.industry, replicate = TRUE)

    return(the.B)

    # depreciation.rate.sector19<-rep(0.1, n.industry)
    # B.fixed.assets <- sweep(compute.A.industry_fixed.assets(),
    #                         2,
    #                         1-depreciation.rate.sector19, "*")
    #
    # return(B.fixed.assets)
  }

  compute.A.industry_inventory <- function(){
    #an estimation of inventory input
    inventory.input <- abs(IOT2[, "FU202"])*2
    A.inventory <- diag (inventory.input/IOT2[, "TO"])
    dimnames(A.inventory) <- list(names.industry, names.industry)
    return(A.inventory)
  }

  compute.B.industry_inventory <- function (){
    return( compute.A.industry_inventory() )
  }

  compute.A.household <- function(state){
    p <- as.vector(state$p)
    names(p) <- names.subject

    p <- p/p["CE"]
    current.income <- sum( p[c("CE","NTP","OS")] * compute.B.household() )


    # commodity demand --------------------------------------------------------

    #A.consumption.domestic <- consumption/IOT["CE","TIU"] * (1-ratio.commodity.import)
    # A.consumption.domestic <- current.income * ratio.consumption.to.income *
    #   consumption.structure/sum(consumption.structure * p[names.industry]) *
    #   (1-ratio.commodity.import)

    #A.consumption.foreign <- consumption/IOT["CE","TIU"] * ratio.commodity.import
    # A.consumption.foreign <- current.income * ratio.consumption.to.income *
    #   consumption.structure/sum(consumption.structure * p[names.industry]) *
    #   ratio.commodity.import
    #
    # A.consumption.foreign <- A.consumption.foreign[-index.zero.import]

    # A.household_commodity <- cbind(c(A.consumption.domestic,
    #                                  A.consumption.foreign))
    tmp.consumption.structure<-compute.consumption.structure(state)
    A.household_commodity <- current.income * ratio.consumption.to.income *
      tmp.consumption.structure/
      sum(tmp.consumption.structure * p[seq_along(tmp.consumption.structure)])

    A.household_commodity <- cbind(A.household_commodity)

    colnames(A.household_commodity) <- "HG"
    rownames(A.household_commodity) <- c(names.industry, names.foreign.trade)


    # bond demand -------------------------------------------------------------


    #tmp.consumption <- sum( compute.A.household_commodity() * p[seq_len(n.industry+n.foreign.trade)] )

    #bond.domestic_expenditure.coefficient <- tmp.consumption * ratio.investment.domestic.to.consumption / p["DB"]
    #bond.foreign_expenditure.coefficient <- tmp.consumption * ratio.investment.foreign.to.consumption / p["FB"]

    bond.domestic_expenditure.coefficient <- current.income * ratio.investment.domestic.to.income / p["DB"]
    bond.foreign_expenditure.coefficient <- current.income * ratio.investment.foreign.to.income / p["FB"]

    A.household_bond <- rbind(bond.domestic_expenditure.coefficient,
                              bond.foreign_expenditure.coefficient)

    colnames(A.household_bond) <- "HG"
    rownames(A.household_bond) <- c("DB", "FB")


    A.household <- rbind(A.household_commodity, A.household_bond)

    return(A.household)
  }

  compute.B.household <- function(){
    # 这里的赋值在sdm计算中不必要（因为用S0Exg控制外生供给），但为了与结构均衡模型一致写在这里
    B.household <- IOT[c("CE","NTP","OS"),"TIU"]/IOT["CE", "TIU"]
    B.household <- cbind(B.household)
    colnames(B.household) <- "HG"
    rownames(B.household) <- c("CE","NTP","OS")

    return(B.household)
  }


  compute.A.ROW <- function(state){
    p <- as.vector(state$p)
    names(p) <- names.subject

    A.bond.foreign<-CGE::CD_A(alpha * foreign.exchange.rate.coefficient,
                              matrix(beta, n.industry, 1),p[names.industry])
    A.bond.foreign <- cbind(A.bond.foreign)
    colnames(A.bond.foreign) <- "ROW"
    rownames(A.bond.foreign) <- names.industry
    return(A.bond.foreign)
  }

  compute.B.ROW <- function(){
    B.bond.foreign <- matrix(1, dimnames = list("FB", "ROW"))
    return(B.bond.foreign)
  }
  ## beginning of compute.A.B #####


  # A.constant --------------------------------------------------------------
  initial.zero.matrix <- matrix(0, n.subject, n.sector, dimnames = list(names.subject, names.sector))


  A.constant <- matrix.add.by.name(initial.zero.matrix,
                                   compute.A.industry_basic(),
                                   compute.A.industry_labor(),
                                   compute.A.industry_fixed.assets(),
                                   compute.A.industry_inventory()
  )

  B.constant <- matrix.add.by.name(initial.zero.matrix,
                          compute.B.industry_basic(),
                          compute.B.industry_fixed.assets(),
                          compute.B.industry_inventory(),

                          compute.B.foreign.trade(),

                          compute.B.household(),
                          compute.B.ROW()
  )

  compute.A.variable <- function (state){
    A.variable <- matrix.add.by.name(initial.zero.matrix,
                                     compute.A.industry_production.tax(state),
                                     compute.A.industry_operating.surplus(state),
                                     compute.A.household(state),
                                     compute.A.foreign.trade(state),
                                     compute.A.ROW(state)
    )
  }

  compute.B.variable <- function (state){
    B.variable <- matrix.add.by.name(initial.zero.matrix,
                                     compute.B.industry_bond.domestic(state),
                                     compute.B.industry_production.tax(state))
  }

  compute.A <- function (state){
    return(A.constant+compute.A.variable(state))
  }

  compute.B <- function (state){
    return(B.constant+compute.B.variable(state))
  }
  # return ------------------------------------------------------------------

  switch(which,
         "ge"={},

         "A.B"=return(list(compute.A=compute.A,
                           A.constant=A.constant,
                           compute.A.variable=compute.A.variable,
                           compute.B=compute.B,
                           B.constant=B.constant,
                           compute.B.variable=compute.B.variable,

                           A.industry_basic=compute.A.industry_basic(),
                           A.industry_labor=compute.A.industry_labor(),
                           A.industry_fixed.assets=compute.A.industry_fixed.assets(),
                           A.industry_inventory=compute.A.industry_inventory(),

                           B.industry_basic=compute.B.industry_basic(),
                           B.industry_fixed.assets=compute.B.industry_fixed.assets(),
                           B.industry_inventory=compute.B.industry_inventory(),

                           B.foreign.trade=compute.B.foreign.trade(),

                           B.household=compute.B.household(),
                           B.ROW=compute.B.ROW(),

                           compute.A.industry_production.tax=compute.A.industry_production.tax,
                           compute.A.industry_operating.surplus=compute.A.industry_operating.surplus,
                           compute.A.household=compute.A.household,
                           compute.A.foreign.trade=compute.A.foreign.trade,
                           compute.A.ROW=compute.A.ROW,

                           compute.B.industry_bond.domestic=compute.B.industry_bond.domestic,
                           compute.B.industry_production.tax=compute.B.industry_production.tax,

                           n.industry= n.industry,
                           n.foreign.trade=n.foreign.trade,
                           n.sector=n.sector,
                           n.subject=n.subject,
                           n.sector_product=n.industry+n.foreign.trade,
                           names.industry=names.industry,
                           names.subject=names.subject,
                           names.sector=names.sector,
                           IOT1=IOT1,
                           IOT2=IOT2,
                           IOT3=IOT3)


         ),
         stop("Li: Wrong which")
  )


  # compute equilibrium -----------------------------------------------------

  ge <- sdm(
    A=compute.A,
    B=compute.B,
    n=n.subject,
    m=n.sector,
    S0Exg={
      S0Exg<-matrix(NA, n.subject, n.sector, dimnames = list(names.subject, names.sector))
      S0Exg[c("CE","NTP","OS"),"HG"]<-c(1, 0.2786699, 0.4822470)*labor.supply
      S0Exg
    },
    GRExg=GRExg,
    z0={
      z0<-numeric(n.sector)
      names(z0)<-names.sector
      z0[names.industry]<-IOT2[,"TO"]/NSE::ChinaInputOutputTable2012[141,"TIU"]*labor.supply
      z0[names.foreign.trade]<-IOT2[,"IM"][IOT2[,"IM"]>0]/NSE::ChinaInputOutputTable2012[141,"TIU"]*labor.supply
      z0["HG"]<-labor.supply
      z0["ROW"]<-foreign.trade.surplus/NSE::ChinaInputOutputTable2012[141,"TIU"]*labor.supply
      cbind(z0)},
    priceAdjustmentVelocity=0.03,
    exchangeFunction=NSE:::F_Z2
    #...
    # substitutionMethod=substitutionMethod,
    # maxIteration = maxIteration,

    )


  names(ge$p) <- rownames(ge$A) <- rownames(ge$S) <- names.subject
  names(ge$z) <- colnames(ge$A) <- colnames(ge$S) <- names.sector

  ge$p <- ge$p/ge$p["CE"]


  return(ge)

}

#IOT19<-data.compress(ChinaInputOutputTable2012); ge<-ccge(IOT=IOT19); ge$z[1:3]

