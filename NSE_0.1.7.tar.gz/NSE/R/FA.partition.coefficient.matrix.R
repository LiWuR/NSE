FA.partition.coefficient.matrix<-function(which=19){
  result<-matrix(0,19,19)
  rownames(result)<-colnames(result)<-make.code()

  result["I01_19","I01_19"]<-1 #农林牧渔
  result["I06_19","I06_19"]<-1 #批发零售
  result["I07_19","I07_19"]<-1 #交通仓储
  result["I09_19","I09_19"]<-1 #信息软件
  result["I11_19","I11_19"]<-1 #房地产
  result["I13_19","I13_19"]<-1 #科技服务

  result[c(3,5), ]<-1
  return(result)
}
