#' @export

#Cobb-Douglas three-sector corn economy
dual.economy.CD_2_3<-function(technology.progress.rate=0.001,
                              theta=2.1,
                              z0=c(0.01,100,1),
                              beginning.time.tp=1,
                              numberOfPeriods=200){
  sdm(
    A=function(state){
      alpha<-rbind(theta,1,1)
      if (state$t>=beginning.time.tp) alpha[1]<-alpha[1]*(1+technology.progress.rate)^(state$t-beginning.time.tp)

      Beta<-matrix(c(0.5, 0, 1,
                     0.5, 1, 0),2,3,TRUE)
      CGE::CD_A(alpha,Beta,state$p)},
    B=matrix(c(1, 1, 0,
               0, 0, 1),2,3,TRUE),
    S0Exg=matrix(c(NA, NA, NA,
                   NA, NA, 100),2,3,TRUE),
    GRExg=0,
    z0=z0,
    maxIteration=1,
    numberOfPeriods=numberOfPeriods,
    ts=TRUE
  )
}



