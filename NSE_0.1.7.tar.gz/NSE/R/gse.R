# foo <- function(...)
# {
#   for (k in 1:length(list(...))){
#     print(substitute(list(...)[k]))
#   }
# }
#
# x=1
# foo(x,y=2,z=3)
#
# make.cumstoms.names <- function (x=c("CHN","USA","ROW")){
#   library(stringr)
#   y <- t(outer(x,x,FUN = "paste"))
#   diag(y) <- NA
#   y <- str_replace_all(y," ","_")
#   matrix(y[!is.na(y)], length(x)-1)
# }


#library(CGE)


# gse ---------------------------------------------------------------------
# new version, 201906 -----------------------------------------------------

#' @export
gse <- function(
  ._tax.rate.CHN_USA = 0.05,
  ._tax.rate.CHN_ROW = 0.05,

  ._tax.rate.USA_CHN = 0.05,
  ._tax.rate.USA_ROW = 0.05,

  ._tax.rate.ROW_CHN = 0.05,
  ._tax.rate.ROW_USA = 0.05,

  ._labor.CHN = 50,
  ._dividend.CHN = 30,
  ._tax.CHN = 20,
  ._consumption.rate.CHN = 0.5,
  ._bond.CHN = 2,

  ._labor.USA = 100,
  ._dividend.USA = 60,
  ._tax.USA = 40,
  ._consumption.rate.USA = 0.6,
  ._bond.USA = 4,

  ._labor.ROW = 200,
  ._dividend.ROW = 120,
  ._tax.ROW = 80,
  ._consumption.rate.ROW = 0.5,
  ._bond.ROW = 8,

  ._sigma.industry.CHN = -0.5,
  ._alpha.industry.CHN = 10,
  ._beta.industry.CHN_CHN = 0.6,
  ._beta.industry.CHN_USA = 0.2,
  ._beta.industry.CHN_ROW = 0.2,

  ._sigma.industry.USA = -0.5,
  ._alpha.industry.USA = 10,
  ._beta.industry.USA_USA = 0.5,
  ._beta.industry.USA_CHN = 0.3,
  ._beta.industry.USA_ROW = 0.2,

  ._sigma.industry.ROW = -0.5,
  ._alpha.industry.ROW = 10,
  ._beta.industry.ROW_ROW = 0.6,
  ._beta.industry.ROW_CHN = 0.2,
  ._beta.industry.ROW_USA = 0.2,

  ._industry.labor.coef.CHN = 0.1,
  ._industry.labor.coef.USA = 0.1,
  ._industry.labor.coef.ROW = 0.1,

  ._industry.ratio_tax_labor.CHN = 0.2,
  ._industry.ratio_tax_labor.USA = 0.2,
  ._industry.ratio_tax_labor.ROW = 0.2,

  ._industry.ratio_dividend_labor.CHN = 0.2,
  ._industry.ratio_dividend_labor.USA = 0.2,
  ._industry.ratio_dividend_labor.ROW = 0.2,

  ._sigma.consumer.CHN = -0.5,
  ._beta.consumer.CHN_CHN = 0.6,
  ._beta.consumer.CHN_USA = 0.2,
  ._beta.consumer.CHN_ROW = 0.2,

  ._sigma.consumer.USA = -0.5,
  ._beta.consumer.USA_USA = 0.5,
  ._beta.consumer.USA_CHN = 0.3,
  ._beta.consumer.USA_ROW = 0.2,

  ._sigma.consumer.ROW = -0.5,
  ._beta.consumer.ROW_ROW = 0.6,
  ._beta.consumer.ROW_CHN = 0.2,
  ._beta.consumer.ROW_USA = 0.2,

  ._domestic.investment.rate.CHN = 0.8,
  ._domestic.investment.rate.USA = 0.5,
  ._domestic.investment.rate.ROW = 0.8,

  ._investor.bond.rate.CHN_USA = 0.5,
  ._investor.bond.rate.CHN_ROW = 0.5,

  ._investor.bond.rate.USA_CHN = 0.1,
  ._investor.bond.rate.USA_ROW = 0.9,

  ._investor.bond.rate.ROW_CHN = 0.1,
  ._investor.bond.rate.ROW_USA = 0.9) {


  small.number <- 1e-3

  account.zero <- c(
    product.CHN = 0,
    labor.CHN = 0,
    bond.CHN = 0,
    tax.CHN = 0,
    dividend.CHN = 0,
    taxed.product.CHN_USA = 0,
    taxed.product.CHN_ROW = 0,

    product.USA = 0,
    labor.USA = 0,
    bond.USA = 0,
    tax.USA = 0,
    dividend.USA = 0,
    taxed.product.USA_CHN = 0,
    taxed.product.USA_ROW = 0,

    product.ROW = 0,
    labor.ROW = 0,
    bond.ROW = 0,
    tax.ROW = 0,
    dividend.ROW = 0,
    taxed.product.ROW_CHN = 0,
    taxed.product.ROW_USA = 0
  )

  # exogenous supply --------------------------------------------------------
  s.industry.CHN <- s.consumer.CHN <- s.investor.CHN <-
    s.customs.CHN_USA <- s.customs.CHN_ROW <-

    s.industry.USA <- s.consumer.USA <- s.investor.USA <-
    s.customs.USA_CHN <- s.customs.USA_ROW <-

    s.industry.ROW <- s.consumer.ROW <- s.investor.ROW <-
    s.customs.ROW_CHN <- s.customs.ROW_USA <-
    account.zero * NA

  s.consumer.CHN["labor.CHN"] <- ._labor.CHN * ._consumption.rate.CHN
  s.consumer.CHN["dividend.CHN"] <- ._dividend.CHN * ._consumption.rate.CHN
  s.consumer.CHN["tax.CHN"] <- ._tax.CHN * ._consumption.rate.CHN

  s.investor.CHN["labor.CHN"] <- ._labor.CHN * (1 - ._consumption.rate.CHN)
  s.investor.CHN["dividend.CHN"] <- ._dividend.CHN * (1 - ._consumption.rate.CHN)
  s.investor.CHN["tax.CHN"] <- ._tax.CHN * (1 - ._consumption.rate.CHN)
  s.investor.CHN["bond.CHN"] <- ._bond.CHN



  s.consumer.USA["labor.USA"] <- ._labor.USA * ._consumption.rate.USA
  s.consumer.USA["dividend.USA"] <- ._dividend.USA * ._consumption.rate.USA
  s.consumer.USA["tax.USA"] <- ._tax.USA * ._consumption.rate.USA

  s.investor.USA["labor.USA"] <- ._labor.USA * (1 - ._consumption.rate.USA)
  s.investor.USA["dividend.USA"] <- ._dividend.USA * (1 - ._consumption.rate.USA)
  s.investor.USA["tax.USA"] <- ._tax.USA * (1 - ._consumption.rate.USA)
  s.investor.USA["bond.USA"] <- ._bond.USA

  s.consumer.ROW["labor.ROW"] <- ._labor.ROW * ._consumption.rate.ROW
  s.consumer.ROW["dividend.ROW"] <- ._dividend.ROW * ._consumption.rate.ROW
  s.consumer.ROW["tax.ROW"] <- ._tax.ROW * ._consumption.rate.ROW

  s.investor.ROW["labor.ROW"] <- ._labor.ROW * (1 - ._consumption.rate.ROW)
  s.investor.ROW["dividend.ROW"] <- ._dividend.ROW * (1 - ._consumption.rate.ROW)
  s.investor.ROW["tax.ROW"] <- ._tax.ROW * (1 - ._consumption.rate.ROW)
  s.investor.ROW["bond.ROW"] <- ._bond.ROW


  # run sdm -----------------------------------------------------------------


  ge <- sdm(
    A = function(state) {
      p <- state$p
      names(p) <- names(account.zero)

      a.industry.CHN <- a.consumer.CHN <- a.investor.CHN <-
        a.customs.CHN_USA <- a.customs.CHN_ROW <-

        a.industry.USA <- a.consumer.USA <- a.investor.USA <-
        a.customs.USA_CHN <- a.customs.USA_ROW <-

        a.industry.ROW <- a.consumer.ROW <- a.investor.ROW <-
        a.customs.ROW_CHN <- a.customs.ROW_USA <-
        account.zero

      # a.industry.CHN --------------------------------------------------------
      a.industry.CHN[c(
        "product.CHN",
        "taxed.product.CHN_USA",
        "taxed.product.CHN_ROW"
      )] <-
        CES_A(
          ._sigma.industry.CHN, ._alpha.industry.CHN, rbind(
            ._beta.industry.CHN_CHN,
            ._beta.industry.CHN_USA,
            ._beta.industry.CHN_ROW
          ),
          p[c("product.CHN", "taxed.product.CHN_USA", "taxed.product.CHN_ROW")]
        )


      a.industry.CHN["labor.CHN"] <- ._industry.labor.coef.CHN


      a.industry.CHN["tax.CHN"] <- ._industry.ratio_tax_labor.CHN * a.industry.CHN["labor.CHN"] * p["labor.CHN"] /
        p["tax.CHN"]

      a.industry.CHN["dividend.CHN"] <- ._industry.ratio_dividend_labor.CHN * a.industry.CHN["labor.CHN"] * p["labor.CHN"] /
        p["dividend.CHN"]


      # a.consumer.CHN --------------------------------------------------------
      consumer.income.CHN <- sum(ifelse(is.na(s.consumer.CHN), 0, s.consumer.CHN) * p)

      tmp.consumption.bundle <- CES_A(
        ._sigma.consumer.CHN, 1, rbind(
          ._beta.consumer.CHN_CHN,
          ._beta.consumer.CHN_USA,
          ._beta.consumer.CHN_ROW
        ),
        p[c("product.CHN", "taxed.product.CHN_USA", "taxed.product.CHN_ROW")]
      )

      a.consumer.CHN[c(
        "product.CHN",
        "taxed.product.CHN_USA",
        "taxed.product.CHN_ROW"
      )] <- tmp.consumption.bundle #* consumer.income.CHN /sum(tmp.consumption.bundle *p[c("product.CHN", "taxed.product.CHN_USA", "taxed.product.CHN_ROW")])

      # a.investor.CHN --------------------------------------------------------
      investor.income.CHN <- sum(ifelse(is.na(s.investor.CHN), 0, s.investor.CHN) * p)

      abroad.investment.rate.CHN <- 1 - ._domestic.investment.rate.CHN

      tmp.investment.bundle <- CES_A(
        ._sigma.industry.CHN, 1, rbind(
          ._beta.industry.CHN_CHN,
          ._beta.industry.CHN_USA,
          ._beta.industry.CHN_ROW
        ),
        p[c("product.CHN", "taxed.product.CHN_USA", "taxed.product.CHN_ROW")]
      )

      a.investor.CHN[c(
        "product.CHN",
        "taxed.product.CHN_USA",
        "taxed.product.CHN_ROW"
      )] <- tmp.investment.bundle * investor.income.CHN * ._domestic.investment.rate.CHN /
        sum(tmp.investment.bundle *
              p[c("product.CHN", "taxed.product.CHN_USA", "taxed.product.CHN_ROW")])

      a.investor.CHN[c(
        "bond.USA",
        "bond.ROW"
      )] <- investor.income.CHN * abroad.investment.rate.CHN * c(
        ._investor.bond.rate.CHN_USA,
        ._investor.bond.rate.CHN_ROW
      ) /
        p[c(
          "bond.USA",
          "bond.ROW"
        )]

      # a.customs.CHN_USA ---------------------------------------------------------
      a.customs.CHN_USA["product.USA"] <- 1
      a.customs.CHN_USA["tax.CHN"] <- p["product.USA"] *
        ._tax.rate.CHN_USA / p["tax.CHN"]

      # a.customs.CHN_ROW ---------------------------------------------------------
      a.customs.CHN_ROW["product.ROW"] <- 1
      a.customs.CHN_ROW["tax.CHN"] <- p["product.ROW"] *
        ._tax.rate.CHN_ROW / p["tax.CHN"]

      # a.industry.USA ----------------------------------------------------------
      a.industry.USA[c(
        "product.USA",
        "taxed.product.USA_CHN",
        "taxed.product.USA_ROW"
      )] <-
        CES_A(
          ._sigma.industry.USA, ._alpha.industry.USA, rbind(
            ._beta.industry.USA_USA,
            ._beta.industry.USA_CHN,
            ._beta.industry.USA_ROW
          ),
          p[c("product.USA", "taxed.product.USA_CHN", "taxed.product.USA_ROW")]
        )

      a.industry.USA["labor.USA"] <- ._industry.labor.coef.USA

      a.industry.USA["tax.USA"] <- ._industry.ratio_tax_labor.USA * a.industry.USA["labor.USA"] * p["labor.USA"] /
        p["tax.USA"]

      a.industry.USA["dividend.USA"] <- ._industry.ratio_dividend_labor.USA * a.industry.USA["labor.USA"] * p["labor.USA"] /
        p["dividend.USA"]

      # a.consumer.USA ----------------------------------------------------------
      consumer.income.USA <- sum(ifelse(is.na(s.consumer.USA), 0, s.consumer.USA) * p)



      tmp.consumption.bundle <- CES_A(
        ._sigma.consumer.USA, 1, rbind(
          ._beta.consumer.USA_USA,
          ._beta.consumer.USA_CHN,
          ._beta.consumer.USA_ROW
        ),
        p[c("product.USA", "taxed.product.USA_CHN", "taxed.product.USA_ROW")]
      )

      a.consumer.USA[c(
        "product.USA",
        "taxed.product.USA_CHN",
        "taxed.product.USA_ROW"
      )] <- tmp.consumption.bundle #* consumer.income.USA /  sum(tmp.consumption.bundle *  p[c("product.USA", "taxed.product.USA_CHN", "taxed.product.USA_ROW")])

      # a.investor.USA --------------------------------------------------------
      investor.income.USA <- sum(ifelse(is.na(s.investor.USA), 0, s.investor.USA) * p)

      abroad.investment.rate.USA <- 1 - ._domestic.investment.rate.USA

      tmp.investment.bundle <- CES_A(
        ._sigma.industry.USA, 1, rbind(
          ._beta.industry.USA_USA,
          ._beta.industry.USA_CHN,
          ._beta.industry.USA_ROW
        ),
        p[c("product.USA", "taxed.product.USA_CHN", "taxed.product.USA_ROW")]
      )

      a.investor.USA[c(
        "product.USA",
        "taxed.product.USA_CHN",
        "taxed.product.USA_ROW"
      )] <- tmp.investment.bundle * investor.income.USA * ._domestic.investment.rate.USA /
        sum(tmp.investment.bundle *
              p[c("product.USA", "taxed.product.USA_CHN", "taxed.product.USA_ROW")])

      a.investor.USA[c(
        "bond.CHN",
        "bond.ROW"
      )] <- investor.income.USA * abroad.investment.rate.USA * c(
        ._investor.bond.rate.USA_CHN,
        ._investor.bond.rate.USA_ROW
      ) /
        p[c(
          "bond.CHN",
          "bond.ROW"
        )]


      # a.customs.USA_CHN ---------------------------------------------------------
      a.customs.USA_CHN["product.CHN"] <- 1
      a.customs.USA_CHN["tax.USA"] <- p["product.CHN"] *
        ._tax.rate.USA_CHN / p["tax.USA"]

      # a.customs.USA_ROW ---------------------------------------------------------
      a.customs.USA_ROW["product.ROW"] <- 1
      a.customs.USA_ROW["tax.USA"] <- p["product.ROW"] *
        ._tax.rate.USA_ROW / p["tax.USA"]

      # a.industry.ROW ----------------------------------------------------------
      a.industry.ROW[c(
        "product.ROW",
        "taxed.product.ROW_CHN",
        "taxed.product.ROW_USA"
      )] <-
        CES_A(
          ._sigma.industry.ROW, ._alpha.industry.ROW, rbind(
            ._beta.industry.ROW_ROW,
            ._beta.industry.ROW_CHN,
            ._beta.industry.ROW_USA
          ),
          p[c("product.ROW", "taxed.product.ROW_CHN", "taxed.product.ROW_USA")]
        )


      a.industry.ROW["labor.ROW"] <- ._industry.labor.coef.ROW

      a.industry.ROW["tax.ROW"] <- ._industry.ratio_tax_labor.ROW * a.industry.ROW["labor.ROW"] * p["labor.ROW"] /
        p["tax.ROW"]

      a.industry.ROW["dividend.ROW"] <- ._industry.ratio_dividend_labor.ROW * a.industry.ROW["labor.ROW"] * p["labor.ROW"] /
        p["dividend.ROW"]

      # a.consumer.ROW ----------------------------------------------------------
      consumer.income.ROW <- sum(ifelse(is.na(s.consumer.ROW), 0, s.consumer.ROW) * p)

      tmp.consumption.bundle <- CES_A(
        ._sigma.consumer.ROW, 1, rbind(
          ._beta.consumer.ROW_ROW,
          ._beta.consumer.ROW_CHN,
          ._beta.consumer.ROW_USA
        ),
        p[c("product.ROW", "taxed.product.ROW_CHN", "taxed.product.ROW_USA")]
      )

      a.consumer.ROW[c(
        "product.ROW",
        "taxed.product.ROW_CHN",
        "taxed.product.ROW_USA"
      )] <- tmp.consumption.bundle #* consumer.income.ROW /  sum(tmp.consumption.bundle *  p[c("product.ROW", "taxed.product.ROW_CHN", "taxed.product.ROW_USA")])


      # a.investor.ROW --------------------------------------------------------
      investor.income.ROW <- sum(ifelse(is.na(s.investor.ROW), 0, s.investor.ROW) * p)

      abroad.investment.rate.ROW <- 1 - ._domestic.investment.rate.ROW

      tmp.investment.bundle <- CES_A(
        -1.000, 10.000, rbind(0.6000, 0.2000, 0.2000),
        p[c("product.ROW", "taxed.product.ROW_CHN", "taxed.product.ROW_USA")]
      )

      a.investor.ROW[c(
        "product.ROW",
        "taxed.product.ROW_CHN",
        "taxed.product.ROW_USA"
      )] <- tmp.investment.bundle * investor.income.ROW * ._domestic.investment.rate.ROW /
        sum(tmp.investment.bundle *
              p[c("product.ROW", "taxed.product.ROW_CHN", "taxed.product.ROW_USA")])

      a.investor.ROW[c(
        "bond.CHN",
        "bond.USA"
      )] <- investor.income.ROW * abroad.investment.rate.ROW * c(
        ._investor.bond.rate.ROW_CHN,
        ._investor.bond.rate.ROW_USA
      ) /
        p[c(
          "bond.CHN",
          "bond.USA"
        )]



      # a.customs.ROW_CHN ---------------------------------------------------------
      a.customs.ROW_CHN["product.CHN"] <- 1
      a.customs.ROW_CHN["tax.ROW"] <- p["product.CHN"] *
        ._tax.rate.ROW_CHN / p["tax.ROW"]

      # a.customs.ROW_USA ---------------------------------------------------------
      a.customs.ROW_USA["product.USA"] <- 1
      a.customs.ROW_USA["tax.ROW"] <- p["product.USA"] *
        ._tax.rate.ROW_USA / p["tax.ROW"]


      cbind(
        a.industry.CHN,
        a.consumer.CHN,
        a.investor.CHN,
        a.customs.CHN_USA,
        a.customs.CHN_ROW,

        a.industry.USA,
        a.consumer.USA,
        a.investor.USA,
        a.customs.USA_CHN,
        a.customs.USA_ROW,

        a.industry.ROW,
        a.consumer.ROW,
        a.investor.ROW,
        a.customs.ROW_CHN,
        a.customs.ROW_USA
      )
    },

    # B -----------------------------------------------------------------------
    B = {
      b.industry.CHN <- b.consumer.CHN <- b.investor.CHN <-
        b.customs.CHN_USA <- b.customs.CHN_ROW <-

        b.industry.USA <- b.consumer.USA <- b.investor.USA <-
        b.customs.USA_CHN <- b.customs.USA_ROW <-

        b.industry.ROW <- b.consumer.ROW <- b.investor.ROW <-
        b.customs.ROW_CHN <- b.customs.ROW_USA <-
        account.zero


      # b.CHN -----------------------------------------------------------------
      b.industry.CHN["product.CHN"] <- 1
      b.customs.CHN_USA["taxed.product.CHN_USA"] <- 1
      b.customs.CHN_ROW["taxed.product.CHN_ROW"] <- 1
      # b.USA -----------------------------------------------------------------
      b.industry.USA["product.USA"] <- 1
      b.customs.USA_CHN["taxed.product.USA_CHN"] <- 1
      b.customs.USA_ROW["taxed.product.USA_ROW"] <- 1
      # b.ROW -----------------------------------------------------------------

      b.industry.ROW["product.ROW"] <- 1
      b.customs.ROW_CHN["taxed.product.ROW_CHN"] <- 1
      b.customs.ROW_USA["taxed.product.ROW_USA"] <- 1

      cbind(
        b.industry.CHN,
        b.consumer.CHN,
        b.investor.CHN,
        b.customs.CHN_USA,
        b.customs.CHN_ROW,

        b.industry.USA,
        b.consumer.USA,
        b.investor.USA,
        b.customs.USA_CHN,
        b.customs.USA_ROW,

        b.industry.ROW,
        b.consumer.ROW,
        b.investor.ROW,
        b.customs.ROW_CHN,
        b.customs.ROW_USA
      )
    },

    # S0Exg -------------------------------------------------------------------
    S0Exg = {
      cbind(
        s.industry.CHN,
        s.consumer.CHN,
        s.investor.CHN,
        s.customs.CHN_USA,
        s.customs.CHN_ROW,

        s.industry.USA,
        s.consumer.USA,
        s.investor.USA,
        s.customs.USA_CHN,
        s.customs.USA_ROW,

        s.industry.ROW,
        s.consumer.ROW,
        s.investor.ROW,
        s.customs.ROW_CHN,
        s.customs.ROW_USA
      )
    }
  )

  ge$sector.names <- c(
    "industry.CHN",
    "consumer.CHN",
    "investor.CHN",
    "customs.CHN_USA",
    "customs.CHN_ROW",

    "industry.USA",
    "consumer.USA",
    "investor.USA",
    "customs.USA_CHN",
    "customs.USA_ROW",

    "industry.ROW",
    "consumer.ROW",
    "investor.ROW",
    "customs.ROW_CHN",
    "customs.ROW_USA"
  )

  names(ge$p) <- names(account.zero)
  names(ge$z) <- ge$sector.names
  return(ge)
}


