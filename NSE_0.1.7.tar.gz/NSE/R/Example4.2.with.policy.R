
#' @export
Example4.2.with.policy <- function() {
  supply.adjustment.direction <- -1
  current.land.supply <- 0
  last.utility <- 0
  span <- 2

  Example4.2.policy <- function(time, state, state.history) {
    if (time == 49) current.land.supply <<- state$S[3, 3]
    if (time >= 50) {
      if (supply.adjustment.direction < 0 &&
        dist(state.history$z[(time - 1):(time - 2), ], method = "euclidean") < 1e-3) {
        if (state.history$z[(time - 1), 3] < last.utility) {
          current.land.supply <<- state$S[3, 3] + span
          supply.adjustment.direction <<- 0
        } else {
          last.utility <<- state.history$z[(time - 1), 3]
          current.land.supply <<- max(state$S[3, 3] - span, 10)
        }
      }

      state$S[3, 3] <- current.land.supply
    }
    state
  }

  sdm(
    A = function(state) {
      sigma <- rbind(-1, -1, -1)
      alpha <- rbind(1, 1, 1)
      Beta <- matrix(c(
        0, 1, 1,
        1, 0, 0,
        1, 0, 0
      ), 3, 3, TRUE)
      CES_A(sigma, alpha, Beta, state$p)
    }, B = diag(3),
    S0Exg = matrix(c(
      NA, NA, NA,
      NA, 100, NA,
      NA, NA, 110
    ), 3, 3, T),
    ts = TRUE,
    maxIteration = 1,
    numberOfPeriods = 600,
    policy = Example4.2.policy
  )
}


