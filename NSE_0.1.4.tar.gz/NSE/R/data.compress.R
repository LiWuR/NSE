#' @export

data.compress<-function(x, from="code139", to="code19",
                        method=sum){
  names.from<-c(NSE::industryNames[,from],
                NSE::foreignTradeNames[as.logical(NSE::foreignTradeNames$IM139_2012), from])
  names.to<-c(NSE::industryNames[,to],
              NSE::foreignTradeNames[as.logical(NSE::foreignTradeNames$IM139_2012), to])


  names.x<-c(colnames(x),rownames(x))
  tmp<-names.from %in% names.x
  names.from<-names.from[tmp]
  names.to<-names.to[tmp]

  granularity<-split(names.from, factor(names.to,levels=unique(names.to)))

  if (is.data.frame(x)) x<-as.matrix(x)

  if (is.numeric(x)) {
    x<-rbind(x)
    if (nrow(x)==1) {
      return(matrix.compress.by.name(x, col.name.list=granularity, method=method))
      # part.to.compress<- x[,names.from, drop=FALSE]
      # part.to.keep<- x[, !(colnames(x) %in% names.from), drop=FALSE]
      #
      # tmp<-matrix.compress.by.name(part.to.compress, col.name.list=granularity, method=method)
      # tmp<-cbind(tmp, part.to.keep)
      # rownames(tmp)<-rownames(x)
      # return(tmp)
    }

    if (ncol(x)==1) return(matrix.compress.by.name(x, row.name.list=granularity, method=method))

    # matrix
    return(matrix.compress.by.name(rbind(x), row.name.list=granularity, col.name.list=granularity, method=method))
  }

  if (is.list(x)) {
    if (!is.null(x$p)) x$p<-data.compress(x$p, from=from, to=to, method=mean)
    if (!is.null(x$z)) x$z<-data.compress(x$z, from=from, to=to, method=sum)
    if (!is.null(x$S)) x$S<-data.compress(x$S, from=from, to=to, method=sum)

    if (!is.null(x$A)) {
      x$A<-matrix.compress.by.name(x$A, row.name.list=granularity, method=sum)
      x$A<-(matrix.compress.by.name(x$A, col.name.list=granularity, method=mean))
    }

    return(x)
  }



}
