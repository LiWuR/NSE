#' @export

write.csv.with.comments <- function(x, file, row.names = TRUE ,comments=c() )
{
  # Write the comments
  append <- FALSE
  for( comment in comments ) {
    line <- paste( sep="", "# ", comment )
    write( line, file=file, append=append )
    append <- TRUE
  }

  # Write the column names. write.csv cannot use append parameter.
  write(paste(c("",colnames(x)),collapse=","), file=file, append=TRUE)
  write.table(x, quote=FALSE, row.names=row.names, col.names = FALSE, sep=",", file=file, append=TRUE)
}


