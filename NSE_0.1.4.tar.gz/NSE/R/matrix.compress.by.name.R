#' @export

matrix.compress.by.name<-function(M.fine, row.name.list=NULL, col.name.list=NULL,
                                  method=sum){

  # if (is.null(row.name.list)) {
  #   row.name.list <- as.list(rownames(M.fine))
  #   names(row.name.list) <- rownames(M.fine)
  # }
  # if (is.null(col.name.list)) {
  #   col.name.list<-as.list(colnames(M.fine))
  #   names(col.name.list) <- colnames(M.fine)
  # }


  #fine-granularity name
  fine.row.name <- unique(unlist(row.name.list))
  fine.col.name <- unique(unlist(col.name.list))


  if (!setequal(fine.row.name, rownames(M.fine))) {
    tmp.names.extra<-setdiff(rownames(M.fine), fine.row.name)
    tmp.list<-as.list(tmp.names.extra)
    names(tmp.list)<-tmp.names.extra
    row.name.list<-c(row.name.list, tmp.list)
  }

  if (!setequal(fine.col.name, colnames(M.fine))) {
    tmp.names.extra<-setdiff(colnames(M.fine), fine.col.name)
    tmp.list<-as.list(tmp.names.extra)
    names(tmp.list)<-tmp.names.extra
    col.name.list<-c(col.name.list, tmp.list)
  }


  #stopifnot(nrow(M.fine)==length(fine.row.name), ncol(M.fine)==length(fine.col.name))

  result<-matrix(0, length(row.name.list), length(col.name.list),
                 dimnames = list(names(row.name.list), names(col.name.list)))

  for (kr in names(row.name.list)){
    for (kc in names(col.name.list)){
      result[kr, kc] <- method( M.fine[row.name.list[[kr]], col.name.list[[kc]]] )
    }
  }

  return(result)
}

