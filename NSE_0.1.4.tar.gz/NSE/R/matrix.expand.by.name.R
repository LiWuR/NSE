#' @export

matrix.expand.by.name<-function(M.coarse, row.name.list=NULL, col.name.list=NULL,
                                replicate=FALSE){

  stopifnot(is.matrix(M.coarse))
  # if (is.null(row.name.list)) {
  #   row.name.list <- as.list(rownames(M.coarse))
  #   names(row.name.list) <- rownames(M.coarse)
  # }
  # if (is.null(col.name.list)) {
  #   col.name.list<-as.list(colnames(M.coarse))
  #   names(col.name.list) <- colnames(M.coarse)
  # }
  #
  # stopifnot(nrow(M.coarse)==length(row.name.list), ncol(M.coarse)==length(col.name.list))

  coarse.row.name <- names(row.name.list)
  coarse.col.name <- names(col.name.list)

  if (!setequal(coarse.row.name, rownames(M.coarse))) {
    tmp.names.extra<-setdiff(rownames(M.coarse), coarse.row.name)
    tmp.list<-as.list(tmp.names.extra)
    names(tmp.list)<-tmp.names.extra
    row.name.list<-c(row.name.list, tmp.list)
  }

  if (!setequal(coarse.col.name, colnames(M.coarse))) {
    tmp.names.extra<-setdiff(colnames(M.coarse), coarse.col.name)
    tmp.list<-as.list(tmp.names.extra)
    names(tmp.list)<-tmp.names.extra
    col.name.list<-c(col.name.list, tmp.list)
  }


  #fine granularity name
  fine.row.name <- unique(unlist(row.name.list))
  fine.col.name <- unique(unlist(col.name.list))

  stopifnot(length(fine.row.name)==length(unlist(row.name.list)),
            length(fine.col.name)==length(unlist(col.name.list)))

  result<-matrix(0, length(fine.row.name), length(fine.col.name),
                 dimnames = list(fine.row.name, fine.col.name))

  for (kr in names(row.name.list)){
    for (kc in names(col.name.list)){
      if (replicate) denominator<-1
      else denominator<-length(row.name.list[[kr]])*length(col.name.list[[kc]])

      result[row.name.list[[kr]], col.name.list[[kc]]] <- result[row.name.list[[kr]], col.name.list[[kc]]]+
        M.coarse[kr, kc]/denominator
    }
  }

  return(result)
}

