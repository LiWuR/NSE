#Cobb-Douglas two-sector corn economy
technology.progress.CD_2_2<-function(technology.progress.rate=0.005){
  library(CGE)
  sdm(
    A=function(state){
      beginning.time.tp<-200
      if (state$t>=beginning.time.tp)
        alpha<-rbind(1,1)*(1+technology.progress.rate)^(state$t-beginning.time.tp)
      else alpha<-rbind(1,1)

      Beta<-matrix(c(0.5, 0.4,
                     0.5, 0.6),2,2,TRUE)
      CD_A(alpha,Beta,state$p)},
    B=diag(2),
    S0Exg=matrix(c(NA, NA,
                   NA, 100),2,2,TRUE),
    GRExg=0,
    maxIteration=1,
    plotIteration=T,
    numberOfPeriods=500,
    ts=T
  )
}

#4-by-4(3i+1c) economy with non-homothetic utility function
technology.progress.4_4<-function(technology.progress.rate=0.005,
                                  theta=c(1, 1.2, 0.5, 1, 1)){
  library(CGE)
  sdm(
    A=function(state){
      beginning.time.tp<-300
      result<-matrix(0,4,4)

      if (state$t>=beginning.time.tp) result[4,1:3]<-theta[1]/(1+technology.progress.rate)^(state$t-beginning.time.tp)
      else result[4,1:3]<-theta[1]

      result[1:3,4]<-c(1,theta[2]*state$z[4]^theta[3],theta[4]*state$z[4]^theta[5])
      result
      },
    B=diag(4),
    S0Exg={
      result<-matrix(NA,4,4)
      result[4,4]<-1
      result
      },
    GRExg=0,
    maxIteration=1,
    plotIteration=T,
    numberOfPeriods=1000,
    priceAdjustmentVelocity=0.02,
    ts=T
  )
}





